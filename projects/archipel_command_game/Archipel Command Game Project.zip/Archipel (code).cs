﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace justinApp
{
    class Program
    {
        public static List<string> items = new List<string>();
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int wood = 0;
            int stone = 0;
            int shovel = 0;
            int pickaxe = 0;
            bool loop = true;
            items.Add("debug item");
            string history = "You2 are a man who want to craft tools. For that you have to search materials in the forest. More infos --> help";
            Dude(history);
            string help = "Command list : craft <shovel; pickaxe>; destroy <shovel; pickaxe>; exit; help; history; objective; search; trash <wood; stone>; <wood; stone>; and some secret commands ...";
            Console.WriteLine(help);
            string objectif = "Objective (temporarily); craft 5 pickaxes --> found 5 golds";
            Dude(objectif);
            Dude("Hello tape ta commande", "!");
            bool pickaxeplan = false;
            int space = 0;
            bool exit = false;
            int timesleep = 15000;
            bool auto = false;
            bool archipelplan = false;
            bool archipel = false;
            int gold = 0;
            bool end = true;
            while (loop)
            {
                string user = Console.ReadLine();
                auto = false;

                switch (user)
                {
                    case "inventory":
                        Inventory(wood, stone);
                        break;
                    case "history":
                        Dude(history);
                        break;
                    case "objective":
                        Dude(objectif);
                        break;
                    case "help":
                        Console.WriteLine(help);
                        break;
                    case "":
                        space = Void(space);
                        break;
                    case "search":
                        Search(rnd, ref wood, ref stone, shovel, ref pickaxeplan, ref archipelplan, ref archipel, ref gold, ref pickaxe);
                        break;
                    case "auto search":
                        auto = true;
                        new Thread(DoAutoSearch).Start();
                        void DoAutoSearch()
                        {
                            while (auto)
                            {
                                Search(rnd, ref wood, ref stone, shovel, ref pickaxeplan, ref archipelplan, ref archipel, ref gold, ref pickaxe);
                                Thread.Sleep(1000);
                            }
                        }
                        break;
                    case "wood":
                        Wood(wood);
                        break;
                    case "trash wood":
                        wood = TrashWood(wood);
                        break;
                    case "craft shovel":
                        CraftShovel(ref wood, ref shovel);
                        break;
                    case "destroy shovel":
                        shovel = DestroyShovel(shovel);
                        break;
                    case "stone":
                        Stone(stone);
                        break;
                    case "trash stone":
                        stone = TrashStone(stone);
                        break;
                    case "exit":
                        exit = true;
                        break;
                    case "fuck pickaxe":
                        Console.WriteLine("You stick your pickaxe up your fucking ass, bitch!");
                        break;
                    case "fuck shovel":
                        Console.WriteLine("Wath ??? Seriously ??? With a shovel dude ??? No, that's disgusting !");
                        break;
                    case "fuck":
                        Dude("Fuck you, american https://youtu.be/P7JRvwfHFwo");
                        break;
                    case "craft pickaxe":
                        CraftPickaxe(ref stone, ref pickaxe, pickaxeplan, ref wood);
                        break;
                    case "destroy pickaxe":
                        pickaxe = DestroyPickaxe(pickaxe, pickaxeplan);
                        break;
                    case "craft archipel":
                        CraftArchipel(ref wood, archipelplan, ref archipel);
                        break;
                    case "?":
                        Console.WriteLine("archipel");
                        break;
                    case "archipel":
                        Archipel();
                        break;
                    case "give archipel":
                        archipel = true;
                        break;
                    case "gold":
                        Dude("You have " + gold + " golds", "!");
                        break;
                    case "give gold":
                        gold = gold + 5;
                        break;
                    default:
                        Dude("No dude");
                        break;
                }
                if (gold > 4)
                {
                    if (end)
                    {
                        Dude("GG ! You found " + gold + " golds ! You're beautiful and strong, like the creator of this game ! De gros bisous", "!");
                        Dude("Do you want to continue ? [y/n]");
                        if (user == "n")
                        {
                            end = false;
                            exit = true;
                        }
                        else if (user == "y")
                        {
                            end = false;
                            Dude("Let's continue !");
                        }
                    }
                }
                if (exit)
                {
                    Console.WriteLine("Fermeture de console dans :");
                    Thread.Sleep(1000);
                    Console.WriteLine("3");
                    Thread.Sleep(1000);
                    Console.WriteLine("2");
                    Thread.Sleep(1000);
                    Console.WriteLine("1");
                    Thread.Sleep(1000);
                    Dude("Bisous");
                    Thread.Sleep(500);
                    loop = false;
                }
            }
        }

        private static void Archipel()
        {
            Console.WriteLine("A quoi sert une archipel ?");
            Console.WriteLine("A creuser des architrous !");
            Console.WriteLine("And found a lot of stone ???");
        }

        private static void CraftArchipel(ref int wood, bool archipelplan, ref bool archipel)
        {
            if (archipelplan)
            {
                if (archipel == false)
                    if (wood > 499)
                    {
                        items.Add("archipel");
                        Dude("Crafted WTF");
                        wood = wood - 500;
                        archipel = true;
                    }
                    else
                    {
                        Dude("Not enough wood");
                    }
                else
                {
                    Dude("Don't abuse");
                }
            }
            else
            {
                Console.WriteLine("What do you mean ? I don't understand ... It seems that you don't have enough chance for that ...");
            }
        }

        private static void Inventory(int wood, int stone)
        {
            foreach (string item in items)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine(wood + " woods !");
            Console.WriteLine(stone + " stones !");
        }

        private static int Void(int space)
        {
            space = space + 1;
            if (space == 10)
            {
                Dude("You're stupid");
                space = 0;
            }
            else
            {
                Dude("No dude");
            }

            return space;
        }

        private static void Search(Random rnd, ref int wood, ref int stone, int shovel, ref bool pickaxeplan, ref bool archipelplan, ref bool archipel, ref int gold, ref int pickaxe)
        {
            int rdm = rnd.Next(0, 4);
            int rdm2 = rnd.Next(0, 10);
            int rdm3 = rnd.Next(0, 3);
            int rdm4 = rnd.Next(0, 100);
            int rdm5 = rnd.Next(0, 100);
            wood = wood + rdm;
            Console.Write("You found ");
            Console.Write(rdm);
            if (rdm < 2)
            {
                Console.WriteLine(" wood dude !");
            }
            else
            {
                Console.WriteLine(" woods dude !");
            }
            if (shovel > 0)
            {
                stone = stone + rdm3;
                Console.Write("You found ");
                Console.Write(rdm3);
                if (rdm3 < 2)
                {
                    Console.WriteLine(" stone dude !");
                }
                else
                {
                    Console.WriteLine(" stones dude !");
                }
            }
            if (archipel)
            {
                stone = stone + rdm4;
                Console.Write("You found ");
                Console.Write(rdm4);
                if (rdm4 < 2)
                {
                    Console.WriteLine(" stone dude !");
                }
                else
                {
                    Console.WriteLine(" stones dude !");
                }
            }
            if (rdm2 == 0)
            {
                if (!pickaxeplan)
                {
                    Dude("You found pickaxe plan");
                }
                Thread.Sleep(1000);
                pickaxeplan = true;
            }
            if (pickaxeplan)
            {
                if (rdm4 == 0)
                {
                    if (archipelplan)
                    {
                    }
                    else
                    {
                        Dude("You found ? plan");
                    }
                    Thread.Sleep(1000);
                    archipelplan = true;
                }
            }
            if (pickaxe > 4)
            {
                if (rdm5 < 10)
                {
                    gold = gold + 1;
                    Dude("You found a gold !");

                }
                if (rdm5 == 10)
                {
                    gold = gold + 2;
                    Dude("You found 2 golds !");
                }
            }
        }

        private static void Wood(int wood)
        {
            Console.Write("You have " + wood);
            if (wood < 2)
            {
                Console.WriteLine(" wood dude !");
            }
            else
            {
                Console.WriteLine(" woods dude !");
            }
        }

        private static int TrashWood(int wood)
        {
            if (wood > 0)
            {
                wood = 0;
                Dude("Wood trashed");
            }
            else
            {
                Dude("You dont have any wood");
            }

            return wood;
        }

        private static void CraftShovel(ref int wood, ref int shovel)
        {
            if (wood > 2)
            {
                items.Add("shovel");
                Dude("Crafted");
                wood = wood - 3;
                shovel = shovel + 1;
            }
            else
            {
                Dude("Not enough wood");
            }
        }

        private static int DestroyShovel(int shovel)
        {
            if (shovel > 0)
            {
                items.Remove("shovel");
                Dude("The shovel has been destroyed");
                shovel = shovel - 1;
            }
            else
            {
                Dude("You don't have any shovel");
            }

            return shovel;
        }

        private static void Stone(int stone)
        {
            Console.Write("You have " + stone);
            if (stone < 2)
            {
                Console.WriteLine(" stone dude !");
            }
            else
            {
                Console.WriteLine(" stones dude !");
            }
        }

        private static int TrashStone(int stone)
        {
            if (stone > 0)
            {
                stone = 0;
                Dude("Stone trashed");
            }
            else
            {
                Dude("You dont have any stone");
            }

            return stone;
        }

        private static int DestroyPickaxe(int pickaxe, bool pickaxeplan)
        {
            if (pickaxe > 0)
            {
                items.Remove("pickaxe");
                Dude("The pickaxe has been destroyed");
                pickaxe = pickaxe - 1;
            }
            else
            {
                if (pickaxeplan == true)
                {
                    Dude("You don't have any pickaxe");
                }
                else
                {
                    Dude("You don't have any \"pickaxe\"");
                }
            }

            return pickaxe;
        }

        private static void CraftPickaxe(ref int stone, ref int pickaxe, bool pickaxeplan, ref int wood)
        {
            if (pickaxeplan)
            {
                if (wood > 0)
                {
                    if (stone > 2)
                    {
                        items.Add("pickaxe");
                        Dude("Crafted");
                        stone = stone - 3;
                        wood = wood - 1;
                        pickaxe = pickaxe + 1;
                    }
                    else
                    {
                        Dude("Not enough stone");
                    }
                }
                else
                {
                    Dude("Not enough wood");
                }
            }
            else
            {
                Console.WriteLine("Pickaxe ? What's this shit ?");
            }
        }

        public static void Dude(string str, string str2 = ".")
        {
            Console.WriteLine("[" + DateTime.Now.ToString() + "] " + str + ", dude" + str2);
        }
    }
}